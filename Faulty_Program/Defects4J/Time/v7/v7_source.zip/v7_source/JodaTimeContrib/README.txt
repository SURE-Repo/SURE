
Joda-Time Contributions area
============================
Joda-Time is a date and time library that vastly improves on the JDK.

The Joda-Time contributions area hosts additional code that may be of
use when working with the main Joda-Time library.
Each of these contributions is licensed using the Apache License v2.0.

Please note that this code is not supported in the same way as the main
Joda-Time code. As such it is possible that methods and classes may come
and go over time without warning - you have been warned!

See the README in each subproject for more details.
